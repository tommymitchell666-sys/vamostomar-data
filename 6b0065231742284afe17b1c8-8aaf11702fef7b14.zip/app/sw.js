/* Quinta Viva offline support. Bump VERSION on every release so phones pick up the new version. */
const VERSION = 'qv-0.9.0-1';
const SHELL = ['/app/', '/app/manifest.webmanifest', '/config.js', '/fonts/fonts.css', '/fonts/bricolage.woff2', '/fonts/literata.woff2', '/fonts/literata-italic.woff2', '/icons/icon-192.png', '/icons/favicon.svg', '/icons/favicon-32.png'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)));
});
self.addEventListener('message', e => { if (e.data === 'skipWaiting') self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;            /* map tiles, analytics: straight to the network */
  const fresh = req.mode === 'navigate' || url.pathname === '/config.js' || url.pathname.endsWith('.webmanifest');
  if (fresh) {                                           /* the app page and settings: network first, cached copy offline */
    e.respondWith(fetch(req).then(r => { const c = r.clone(); caches.open(VERSION).then(x => x.put(req.mode === 'navigate' ? '/app/' : req, c)); return r; })
      .catch(() => caches.match(req.mode === 'navigate' ? '/app/' : req)));
    return;
  }
  e.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => {   /* fonts and icons: cache first */
    if (r.ok) { const c = r.clone(); caches.open(VERSION).then(x => x.put(req, c)); }
    return r;
  })));
});
