/* Quinta Viva settings. Change these, then redeploy. Nothing secret goes in here:
   everyone can read this file. */
window.QV_CONFIG = {
  /* ArcGIS Location Platform API key (tracker task 2.7). Limit it to the site's address. */
  arcgisKey: '',
  /* Cloudflare Web Analytics token (task 2.9). Leave empty for no analytics. */
  cfAnalyticsToken: '',
  /* WhatsApp community invite link (task 2.12) and Facebook page (task 2.13). */
  whatsapp: '',
  facebook: '',
  instagram: 'https://www.instagram.com/quintaviva.app/',
  contactEmail: 'hello@quintaviva.app',
  /* Founding 100: update spotsTaken from the Growers sheet when it changes. */
  spotsTotal: 100,
  spotsTaken: 0,
  /* shown under the counter, e.g. '7 December 2026' (leave empty to hide) */
  spotsUpdated: '',
  /* true closes sign-ups early (it also closes by itself when spotsTaken reaches spotsTotal). */
  doorsClosed: false
};
