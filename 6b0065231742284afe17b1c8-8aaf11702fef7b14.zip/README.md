# Quinta Viva website: how to run it

This folder is the whole site. Netlify serves it as it is, with no build step.

## What's where
- `/` and `/pt/`: the landing page in English and Portuguese, with the Founding 100 counter and sign-up form.
- `/app/`: the app itself (installable, works offline).
- `/privacy/`, `/terms/` (and `/pt/privacidade/`, `/pt/termos/`): the privacy notice, beta terms and Founding 100 terms.
- `/thanks/`, `/pt/obrigado/` (plus `waitlist/` and `lista/`): the pages people see after signing up.
- `config.js`: **the only file you normally change.**
- `__forms.html`: tells Netlify about the three forms (founding, waitlist, feedback). Don't delete it.

## Changing settings (config.js)
Open `config.js`, change a value, save, then deploy again.
- `arcgisKey`: the ArcGIS key from tracker task 2.7. Without it the map uses Esri's public tiles, which are only for testing.
- `cfAnalyticsToken`: the Cloudflare Web Analytics token (task 2.9).
- `whatsapp` / `facebook`: the community invite link and Facebook page.
- `spotsTaken`: how many Founding spots are taken. Copy it from the top of the tracker ("X of 100 taken") whenever it changes. **It must always be the real number.**
- `spotsUpdated`: the date you last updated it, e.g. `'7 December 2026'`.
- `doorsClosed`: set to `true` to close sign-ups early. They close by themselves when `spotsTaken` reaches 100.

## First deploy (once)
1. On Netlify: **Add new site → Deploy manually**, then drag this whole folder (or the zip) onto the page.
2. **Site configuration → Change site name** → `quintaviva` (gives quintaviva.netlify.app).
3. **Forms → Enable form detection**, then deploy again so the forms are picked up.
4. **Forms → Form notifications → Add notification → Email**: your Netlify login email (Netlify only lets you send to team members).
5. Later: **Domain management → Add a domain** for quintaviva.app.

## Every update after that
Netlify → your site → **Deploys** → drag the new folder or zip onto the deploy area.
When the app itself changes, also bump `VERSION` at the top of `app/sw.js` (e.g. `qv-0.9.0-2`) so phones show "A new version of Quinta Viva is ready".

## Before launch
- Read the privacy notice and terms (tracker 4.6) and have the Portuguese pages checked (4.7).
- Put the real ArcGIS key in `config.js` (2.7) and limit the key to your web address (2.6).
